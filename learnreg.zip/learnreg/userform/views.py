from django.shortcuts import render, HttpResponse
from .models import regform
# Create your views here.
from django.contrib.admin.models import LogEntry

LogEntry.objects.all().delete()

def home(request):
    return render(request, 'index.html')

def register(request):
    return render(request, 'register.html')


def newreg(request):
    if request.method == "POST":
        fullname = request.POST.get("fullname")
        username = request.POST.get("username")
        email = request.POST.get("email")
        password = request.POST.get("password")

        regforms = regform()
        regforms.fullname = fullname
        regforms.username = username
        regforms.email = email
        regforms.password = password
        regforms.save()
        return HttpResponse("Registered Successfully.")
        # return render(request, 'index.html')
    else:
        return HttpResponse("Not working sorry")
