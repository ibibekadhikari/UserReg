from django.contrib import admin
from .models import regform
# Register your models here.

admin.site.register(regform)